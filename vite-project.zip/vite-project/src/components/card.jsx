// src/components/Card.jsx
import React from "react";
import "./Card.css";

const Card = ({ image, title, location, price }) => {
  return (
    <div className="card">
      <img src={image} alt={title} className="card-img" />
      <div className="card-info">
        <h4>{title}</h4>
        <p>{location}</p>
        <p><strong>{price}</strong></p>
      </div>
    </div>
  );
};

export default Card;

// src/components/Navbar.jsx
import React from "react";
import { NavLink } from "react-router-dom";
import "./Navbar.css"; // Optional CSS file

const Navbar = () => {
  return (
    <nav className="navbar">
      <NavLink to="/" className="nav-item">Homes</NavLink>
      <NavLink to="/experiences" className="nav-item">Experiences</NavLink>
      <NavLink to="/services" className="nav-item">Services</NavLink>
    </nav>
  );
};

export default Navbar;

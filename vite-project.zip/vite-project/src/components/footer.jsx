import React from "react";

export default function Footer() {
  return (
    <footer className="bg-gray-100 p-6 mt-10 text-center text-sm text-gray-600">
      <p>© 2025 Airbnb Clone | Made with React + Vite</p>
    </footer>
  );
}
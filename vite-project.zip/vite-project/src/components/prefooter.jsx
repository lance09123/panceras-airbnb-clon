import React from "react";

export default function PreFooter() {
  return (
    <div style={{ background: "#f7f7f7", padding: "50px 20px" }}>
      <div style={{ maxWidth: "1200px", margin: "0 auto" }}>
        
        {/* Top: Inspiration for future getaways */}
        <div style={{ marginBottom: "50px" }}>
          <h3 style={{ fontSize: "18px", marginBottom: "20px" }}>
            Inspiration for future getaways
          </h3>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
              gap: "40px",
            }}
          >
            <div>
              <h4 style={{ fontSize: "16px", marginBottom: "10px" }}>Travel tips & inspiration</h4>
              <ul style={{ listStyle: "none", padding: 0, lineHeight: "1.8" }}>
                <li>Airbnb-friendly apartments</li>
                <li>Family travel hub</li>
                <li>Tips and inspiration</li>
                <li>Family budget travel</li>
                <li>Get there for less</li>
              </ul>
            </div>
            <div>
              <h4 style={{ fontSize: "16px", marginBottom: "10px" }}>Vacation ideas for any budget</h4>
              <ul style={{ listStyle: "none", padding: 0, lineHeight: "1.8" }}>
                <li>Make it special without making it spendy</li>
                <li>Travel Europe on a budget</li>
                <li>How to take the kids to Europe for less</li>
              </ul>
            </div>
            <div>
              <h4 style={{ fontSize: "16px", marginBottom: "10px" }}>Outdoor adventure</h4>
              <ul style={{ listStyle: "none", padding: 0, lineHeight: "1.8" }}>
                <li>Explore nature with the family</li>
                <li>Bucket list national parks</li>
                <li>Must-see parks for family travel</li>
                <li>Kid-friendly state parks</li>
                <li>Check out these family-friendly hikes</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom: Support | Hosting | Airbnb */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            gap: "40px",
          }}
        >
          <div>
            <h3 style={{ fontSize: "18px", marginBottom: "12px" }}>Support</h3>
            <ul style={{ listStyle: "none", padding: 0, lineHeight: "1.8" }}>
              <li>Help Center</li>
              <li>Get help with a safety issue</li>
              <li>AirCover</li>
              <li>Anti-discrimination</li>
              <li>Disability support</li>
              <li>Cancellation options</li>
              <li>Report neighborhood concern</li>
            </ul>
          </div>
          <div>
            <h3 style={{ fontSize: "18px", marginBottom: "12px" }}>Hosting</h3>
            <ul style={{ listStyle: "none", padding: 0, lineHeight: "1.8" }}>
              <li>Airbnb your home</li>
              <li>Airbnb your experience</li>
              <li>Airbnb your service</li>
              <li>AirCover for Hosts</li>
              <li>Hosting resources</li>
              <li>Community forum</li>
              <li>Hosting responsibly</li>
              <li>Airbnb-friendly apartments</li>
              <li>Join a free Hosting class</li>
              <li>Find a co-host</li>
            </ul>
          </div>
          <div>
            <h3 style={{ fontSize: "18px", marginBottom: "12px" }}>Airbnb</h3>
            <ul style={{ listStyle: "none", padding: 0, lineHeight: "1.8" }}>
              <li>2025 Summer Release</li>
              <li>Newsroom</li>
              <li>Careers</li>
              <li>Investors</li>
              <li>Gift cards</li>
              <li>Airbnb.org emergency stays</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
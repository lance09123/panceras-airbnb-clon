import React from "react";

export default function SearchBar() {
  return (
    <div className="search-bar">
      <div className="search-box">
        <input type="text" placeholder="Where" />
        <input type="text" placeholder="Date" />
        <input type="text" placeholder="Who" />
        <button>Search</button>
      </div>
    </div>
  );
}
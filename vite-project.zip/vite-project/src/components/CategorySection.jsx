import React from "react";
import Card from "./card";

export default function CategorySection({ title, items }) {
  return (
    <section className="category-section">
      <h2 className="category-title">{title}</h2>
      <div className="card-container">
        {items.map((item, index) => (
          <Card key={index} {...item} />
        ))}
      </div>
    </section>
  );
}
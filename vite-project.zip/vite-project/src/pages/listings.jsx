// pages/Listing.jsx
import React from 'react';
import Card from '../components/card';
import myImage from '../assets/sample.jpg'; // Replace with actual image

const Listing = () => {
  return (
    <div>
      <h1>Listings</h1>
      <div className="card-grid">
        <Card 
          title="Item 1" 
          description="This is item 1" 
          image={myImage} 
        />
        <Card 
          title="Item 2" 
          description="This is item 2" 
          image={myImage} 
        />
        {/* Add more cards as needed */}
      </div>
    </div>
  );
};

export default Listing;
